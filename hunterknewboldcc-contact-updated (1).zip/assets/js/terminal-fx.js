document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('[data-type]').forEach((el) => {
    const text = el.textContent.trim();
    const speed = Number(el.getAttribute('data-speed') || 16);
    if (!text) return;
    el.textContent = '';
    let i = 0;
    const tick = () => {
      el.textContent = text.slice(0, i);
      i += 1;
      if (i <= text.length) window.setTimeout(tick, speed);
    };
    tick();
  });
});
